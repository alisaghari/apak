<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class auction extends Model
{
    //
}
